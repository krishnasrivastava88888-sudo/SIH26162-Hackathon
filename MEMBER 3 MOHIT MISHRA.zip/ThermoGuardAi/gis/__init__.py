"""ThermoGuard GIS intelligence modules."""
