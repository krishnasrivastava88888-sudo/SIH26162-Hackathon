"""One-command runner for Member 3."""
from gis.spatial_analysis import run

if __name__ == "__main__":
    run()
